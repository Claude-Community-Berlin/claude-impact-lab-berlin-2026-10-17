import { useState, type ReactNode } from "react";

type Screen =
  | "welcome" | "onboarding" | "home" | "ask" | "not-found" | "composer" | "result"
  | "arabic" | "settings" | "kita-login" | "dashboard" | "preview" | "published"
  | "documents" | "editor" | "parents" | "system";

type ButtonProps = {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "tertiary" | "danger";
  className?: string;
  disabled?: boolean;
};

function Button({ children, onClick, variant = "primary", className = "", disabled }: ButtonProps) {
  return <button className={`btn btn-${variant} ${className}`} onClick={onClick} disabled={disabled}>{children}</button>;
}

function Logo({ onClick }: { onClick?: () => void }) {
  return (
    <button className="logo" onClick={onClick} aria-label="Kita Companion home">
      <span className="sunflower" aria-hidden="true"><i /></span>
      <span>Kita <b>Companion</b></span>
    </button>
  );
}

function IconButton({ children, label, onClick }: { children: ReactNode; label: string; onClick?: () => void }) {
  return <button className="icon-btn" aria-label={label} title={label} onClick={onClick}>{children}</button>;
}

function ParentTop({ go, arabic = false }: { go: (s: Screen) => void; arabic?: boolean }) {
  return (
    <header className="topbar">
      <Logo onClick={() => go("welcome")} />
      <div className="kita-name">Kita Sonnenblume</div>
      <div className="top-actions">
        <Button variant="secondary" className="language" onClick={() => go(arabic ? "home" : "arabic")}>
          <span>◎</span> {arabic ? "العربية" : "English"} <span>⌄</span>
        </Button>
        <IconButton label={arabic ? "الإعدادات" : "Settings"} onClick={() => go("settings")}>⚙</IconButton>
      </div>
    </header>
  );
}

function Tag({ children, kind = "new" }: { children: ReactNode; kind?: "new" | "deadline" | "closed" | "success" }) {
  return <span className={`tag tag-${kind}`}>{children}</span>;
}

type EventCardProps = {
  icon: string; date: string; title: string; note: string; bring?: string; tag?: ReactNode;
  onAsk?: () => void; rtl?: boolean;
};

function EventCard({ icon, date, title, note, bring, tag, onAsk, rtl }: EventCardProps) {
  return (
    <article className="event-card" dir={rtl ? "rtl" : "ltr"}>
      <div className="event-icon" aria-hidden="true">{icon}</div>
      <div className="event-body">
        <div className="event-meta">{date}{tag}</div>
        <h3>{title}</h3>
        {bring && <p className="bring"><b>✓ {rtl ? "ما يجب فعله:" : bring.startsWith("Bring") ? "Bring:" : "What to do:"}</b> {bring.replace(/^(Bring|What to do):\s*/, "")}</p>}
        <div className="culture"><span>💡</span><p>{note}</p></div>
        {onAsk && <Button variant="secondary" onClick={onAsk}>{rtl ? "اسأل عن هذا" : "Ask about this"} <span aria-hidden="true">→</span></Button>}
      </div>
    </article>
  );
}

function AnswerCard({ arabic = false, lantern = false }: { arabic?: boolean; lantern?: boolean }) {
  const copy = arabic ? {
    answer: "لا. في هذه الروضة، يجب أن يبقى طفلك دون حمى لمدة 24 ساعة قبل العودة.",
    todo: "أبقِ يوسف في المنزل غدًا وأخبر الروضة في الصباح.",
    note: "هذه القاعدة شائعة في ألمانيا لحماية الأطفال والموظفين الآخرين.",
    source: "قواعد الروضة · §4 المرض",
  } : lantern ? {
    answer: "You can make a simple lantern at home with your child, for example from paper and a glass jar. You don't need to buy one.",
    todo: "Make the lantern before Thursday. Bring it to the Kita at 17:00.",
    note: "Making the lantern together at home is part of the tradition.",
    source: "Parent letter · Laternenfest",
  } : {
    answer: "No. In this Kita, your child must be fever-free for 24 hours before coming back.",
    todo: "Keep Yusuf at home tomorrow and tell the Kita in the morning.",
    note: "This rule is common in Germany to protect the other children and staff.",
    source: "House rules · §4 Illness",
  };
  return (
    <article className="answer-card">
      <section><b>{arabic ? "الإجابة" : "Answer"}</b><p>{copy.answer}</p></section>
      <section><b>{arabic ? "ما يجب فعله" : "What to do"}</b><p>{copy.todo}</p></section>
      <section className="culture"><b>💡 {arabic ? "معلومة ثقافية" : "Cultural note"}</b><p>{copy.note}</p></section>
      <span className="source">📄 {copy.source}</span>
    </article>
  );
}

function ChatInput({ go, arabic = false, lunch = false }: { go: (s: Screen) => void; arabic?: boolean; lunch?: boolean }) {
  return (
    <div className="chat-input">
      <input aria-label="Question" defaultValue={lunch ? "Can my son bring his own lunch?" : ""} placeholder={arabic ? "اسأل سؤالًا بلغتك…" : "Ask a question in your language…"} />
      <IconButton label={arabic ? "الميكروفون قريبًا" : "Microphone coming soon"}>♩</IconButton>
      <Button onClick={() => go(lunch ? "not-found" : "ask")}>↑</Button>
    </div>
  );
}

const questions = ["What do I bring tomorrow?", "My child is sick, what do I do?", "What is Eingewöhnung?", "When does the Kita open?"];

function ParentChat({ go, arabic = false }: { go: (s: Screen) => void; arabic?: boolean }) {
  return (
    <section className="chat-panel" dir={arabic ? "rtl" : "ltr"}>
      <div className="section-heading">
        <span className="eyebrow">{arabic ? "مساعد الروضة" : "Kita assistant"}</span>
        <h2>{arabic ? "اسأل عن أي شيء" : "Ask anything"}</h2>
        <p>{arabic ? "اسأل بلغتك. تأتي الإجابات فقط من وثائق روضتك." : "Ask in your language. Answers come only from your Kita's documents."}</p>
      </div>
      <div className="question-chips">
        {(arabic ? ["ماذا أحضر غدًا؟", "طفلي مريض، ماذا أفعل؟", "ما هي فترة التأقلم؟", "متى تفتح الروضة؟"] : questions).map(q => <button className="chip" key={q}>{q}</button>)}
      </div>
      <div className="conversation">
        <div className="parent-bubble">{arabic ? "كان ابني يعاني من الحمى ليلة أمس. هل يمكنه الذهاب غدًا؟" : "My son had a fever last night. Can he go tomorrow?"}</div>
        <AnswerCard arabic={arabic} />
        <div className="answer-actions">
          <Button variant="secondary" onClick={() => go("composer")}>✉ {arabic ? "اكتب إلى الروضة" : "Write to the Kita"}</Button>
          <div><IconButton label="Helpful">👍</IconButton><IconButton label="Not helpful">👎</IconButton></div>
        </div>
      </div>
      <ChatInput go={go} arabic={arabic} />
    </section>
  );
}

function Week({ go, arabic = false, published = false }: { go: (s: Screen) => void; arabic?: boolean; published?: boolean }) {
  const en = [
    { icon: "⚠️", date: "Wed 4 Nov", title: "Sign the trip permission slip", bring: "What to do: Sign the paper and give it to the teacher.", note: "In Germany, Kitas need written permission from parents for every trip outside the Kita.", tag: <Tag kind="deadline">Deadline</Tag> },
    { icon: "🏮", date: "Thu 5 Nov, 17:00", title: "Lantern walk (Laternenfest)", bring: "Bring: a homemade lantern", note: "A German autumn tradition: children walk through the streets with lanterns and sing songs. Parents usually come along.", tag: <Tag>New</Tag>, ask: true },
    { icon: "📅", date: "Fri 6 Nov", title: "Kita closed (staff training)", note: "Please plan other childcare for this day.", tag: <Tag kind="closed">Closed</Tag> },
    { icon: "🧥", date: "Every day", title: "Bring rain trousers and rain boots (Matschhose)", note: "German Kitas go outside in every weather, also in rain and cold." },
  ];
  const ar = [
    { icon: "🏮", date: "الخميس 5 نوفمبر، 17:00", title: "مسيرة الفوانيس (Laternenfest)", bring: "أحضر: فانوسًا منزلي الصنع", note: "تقليد خريفي ألماني: يمشي الأطفال بالفوانيس ويغنون. عادةً يشارك الوالدان.", tag: <Tag>جديد</Tag>, ask: true },
    { icon: "⚠️", date: "الأربعاء 4 نوفمبر", title: "وقّع إذن الرحلة", bring: "وقّع الورقة وأعطها للمربية.", note: "تحتاج الروضات في ألمانيا إلى إذن مكتوب من الوالدين لكل رحلة خارج الروضة.", tag: <Tag kind="deadline">موعد نهائي</Tag> },
    { icon: "📅", date: "الجمعة 6 نوفمبر", title: "الروضة مغلقة (تدريب الموظفين)", note: "يرجى ترتيب رعاية أخرى لطفلك في هذا اليوم.", tag: <Tag kind="closed">مغلق</Tag> },
    { icon: "🧥", date: "كل يوم", title: "أحضر بنطال المطر وحذاء المطر (Matschhose)", note: "تخرج الروضات الألمانية في كل الطقوس، حتى في المطر والبرد." },
  ];
  return (
    <section className="week" dir={arabic ? "rtl" : "ltr"}>
      <div className="section-heading">
        <span className="eyebrow">{arabic ? "2–6 نوفمبر" : "Mon 2 – Fri 6 Nov"}</span>
        <h2>{arabic ? "هذا الأسبوع" : "This week"}</h2>
      </div>
      {(arabic ? ar : en).map((item, i) => <EventCard key={i} {...item} rtl={arabic} onAsk={item.ask ? () => go("ask") : undefined} />)}
      <Button variant="tertiary">{arabic ? "عرض التقويم الكامل" : "See full calendar"} →</Button>
      {published && <p className="fresh-note">✓ {arabic ? "نشرته السيدة فيبر للتو" : "Just published by Frau Weber"}</p>}
    </section>
  );
}

function Welcome({ go }: { go: (s: Screen) => void }) {
  return (
    <main className="welcome">
      <Logo />
      <div className="welcome-copy">
        <span className="eyebrow">Welcome · Willkommen</span>
        <h1>Every parent belongs at their child's Kita – in any language.</h1>
        <p>Clear information. Kind answers. Better days together.</p>
      </div>
      <div className="choice-grid">
        <button className="choice-card" onClick={() => go("onboarding")}>
          <div className="illustration parent-illustration" aria-hidden="true"><span>●</span><i>●</i><b>♥</b></div>
          <div><span className="choice-arrow">→</span><h2>I'm a parent</h2><p>See your Kita's news in your language</p></div>
        </button>
        <button className="choice-card staff-card" onClick={() => go("kita-login")}>
          <div className="illustration building-illustration" aria-hidden="true"><span>☀</span><b>⌂</b><i>♧ ♧</i></div>
          <div><span className="choice-arrow">→</span><h2>Ich arbeite in einer Kita</h2><p>Informationen einmal teilen – alle Eltern verstehen sie</p></div>
        </button>
      </div>
      <footer><span>Demo · no real personal data</span><button onClick={() => go("system")}>Design system</button></footer>
    </main>
  );
}

function Onboarding({ go }: { go: (s: Screen) => void }) {
  const [language, setLanguage] = useState("English");
  return (
    <main className="center-page">
      <Logo onClick={() => go("welcome")} />
      <div className="setup-card">
        <div className="progress"><span className="active" /><span className="active" /><span /></div>
        <span className="eyebrow">Let's get you connected</span>
        <h1>Welcome to your Kita</h1>
        <label><b><span className="step">1</span>Your Kita code</b><input defaultValue="SONNE" /></label>
        <div className="confirmation">✓ <span><b>Kita Sonnenblume, Berlin</b><small>We found your Kita</small></span></div>
        <fieldset>
          <legend><span className="step">2</span>Your language</legend>
          <div className="language-grid">
            {["English", "العربية", "Українська", "Türkçe", "Español"].map(l => <button className={language === l ? "selected" : ""} onClick={() => setLanguage(l)} key={l}>{l}<span>{language === l ? "✓" : ""}</span></button>)}
          </div>
        </fieldset>
        <label><b><span className="step">3</span>Your child's first name <em>Optional</em></b><input placeholder="e.g. Yusuf" defaultValue="Yusuf" /><small>Only used to write messages. Not shared.</small></label>
        <Button className="full" onClick={() => go(language === "العربية" ? "arabic" : "home")}>Continue <span>→</span></Button>
      </div>
    </main>
  );
}

function Home({ go, arabic = false, published = false }: { go: (s: Screen) => void; arabic?: boolean; published?: boolean }) {
  return (
    <div className={arabic ? "app-shell rtl-app" : "app-shell"} dir={arabic ? "rtl" : "ltr"}>
      <ParentTop go={go} arabic={arabic} />
      <main className="parent-main">
        <div className="greeting">
          <div><span className="date">{arabic ? "الاثنين، 2 نوفمبر 2026" : "Monday, 2 November 2026"}</span>
          <h1>{arabic ? "مرحبًا أميرة" : "Hello Amira"} <span aria-hidden="true">👋</span></h1>
          <p>{arabic ? "إليك ما يحدث في روضة يوسف." : "Here is what's happening at Yusuf's Kita."}</p></div>
          <div className="weather">☂ <span>{arabic ? "مطر خفيف · 9°" : "Light rain · 9°"}</span></div>
        </div>
        <div className="parent-columns">
          <Week go={go} arabic={arabic} published={published} />
          <ParentChat go={go} arabic={arabic} />
        </div>
      </main>
      <Button className="mobile-chat" onClick={() => go("ask")}>✦ {arabic ? "اسأل عن أي شيء" : "Ask anything"}</Button>
    </div>
  );
}

function AskScreen({ go }: { go: (s: Screen) => void }) {
  const [loading, setLoading] = useState(false);
  return (
    <div className="app-shell">
      <ParentTop go={go} />
      <main className="focused-chat">
        <Button variant="tertiary" onClick={() => go("home")}>← Back to this week</Button>
        <div className="section-heading"><span className="eyebrow">Kita assistant</span><h1>Ask anything</h1><p>Answers come only from your Kita's documents.</p></div>
        <div className="parent-bubble">What kind of lantern? Do I have to buy one?</div>
        {loading ? <div className="skeleton-card"><p>Reading your Kita's documents…</p><i /><i /><i /></div> : <AnswerCard lantern />}
        <div className="answer-actions">
          <Button variant="secondary" onClick={() => go("composer")}>✉ Write to the Kita</Button>
          <div><IconButton label="Helpful">👍</IconButton><IconButton label="Not helpful">👎</IconButton></div>
        </div>
        <div className="follow-up">
          <p>Try another question</p>
          <button className="chip" onClick={() => go("not-found")}>Can my son bring his own lunch?</button>
          <button className="chip" onClick={() => setLoading(!loading)}>{loading ? "Show answer" : "Show loading state"}</button>
        </div>
        <ChatInput go={go} lunch />
      </main>
    </div>
  );
}

function NotFound({ go }: { go: (s: Screen) => void }) {
  return (
    <div className="app-shell"><ParentTop go={go} /><main className="focused-chat">
      <Button variant="tertiary" onClick={() => go("ask")}>← Back</Button>
      <div className="section-heading"><span className="eyebrow">Kita assistant</span><h1>Ask anything</h1></div>
      <div className="parent-bubble">Can my son bring his own lunch?</div>
      <article className="unknown-card"><span className="unknown-icon">i</span><div><h3>This is not in the Kita's documents</h3><p>I can't find this in your Kita's documents, so I don't want to guess. Please ask the teacher – I can write the message for you in German.</p><Button onClick={() => go("composer")}>✉ Write this question to the Kita</Button></div></article>
    </main></div>
  );
}

function Composer({ go }: { go: (s: Screen) => void }) {
  return (
    <div className="overlay-page">
      <div className="overlay-bg" onClick={() => go("home")} />
      <aside className="composer">
        <div className="panel-head"><div><span className="eyebrow">Message helper</span><h1>Write to the Kita</h1></div><IconButton label="Close" onClick={() => go("home")}>×</IconButton></div>
        <p>Write in your language. We'll turn it into polite German.</p>
        <div className="question-chips">{["My child will be late", "My child is sick", "Pick-up by another person", "I have a question"].map(x => <button className="chip" key={x}>{x}</button>)}</div>
        <label><b>Your message</b><textarea defaultValue="Yusuf will be late tomorrow, he has a doctor appointment." /><small>Write naturally. Short sentences are best.</small></label>
        <div className="privacy-note">✦ <span><b>Your words stay private</b><br />We only use them to make this message.</span></div>
        <Button className="full" onClick={() => go("result")}>Create message in German <span>→</span></Button>
      </aside>
    </div>
  );
}

function Result({ go }: { go: (s: Screen) => void }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="overlay-page">
      <div className="overlay-bg" onClick={() => go("home")} />
      <aside className="composer result-panel">
        {copied && <Toast>Copied! You can send it by email or WhatsApp.</Toast>}
        <div className="panel-head"><div><span className="eyebrow">Ready to send</span><h1>Your message in German</h1></div><IconButton label="Close" onClick={() => go("home")}>×</IconButton></div>
        <div className="german-card"><span className="language-label">DE · German</span><p>Guten Tag Frau Weber,<br /><br />Yusuf kommt morgen etwas später in die Kita, da er einen Arzttermin hat.<br /><br />Vielen Dank und viele Grüße<br />Amira</p></div>
        <div className="translation"><b>What this says:</b><p>Hello Mrs Weber, Yusuf will come to the Kita a little later tomorrow because he has a doctor's appointment. Thank you and best regards, Amira</p></div>
        <div className="correct">✓ <span><b>Polite and correct German.</b><small>Ready to copy into email or WhatsApp.</small></span></div>
        <Button className="full" onClick={() => { navigator.clipboard?.writeText("Guten Tag Frau Weber, Yusuf kommt morgen etwas später in die Kita, da er einen Arzttermin hat."); setCopied(true); }}>▣ Copy message</Button>
        <div className="split-actions"><Button variant="secondary" onClick={() => go("composer")}>Edit</Button><Button variant="tertiary" onClick={() => go("composer")}>Start again</Button></div>
        <Button variant="tertiary" className="back-home" onClick={() => go("home")}>← Back to home</Button>
      </aside>
    </div>
  );
}

function Toast({ children }: { children: ReactNode }) {
  return <div className="toast" role="status"><span>✓</span>{children}</div>;
}

function Settings({ go }: { go: (s: Screen) => void }) {
  return <div className="app-shell"><ParentTop go={go} /><main className="settings-page"><Button variant="tertiary" onClick={() => go("home")}>← Back</Button><h1>Settings</h1>
    <div className="settings-card"><label><b>Language</b><select defaultValue="English"><option>English</option><option>العربية</option><option>Українська</option><option>Türkçe</option><option>Español</option></select></label><label><b>Kita code</b><input defaultValue="SONNE" /></label><label><b>Child's first name</b><input defaultValue="Yusuf" /></label><Button>Save changes</Button><hr /><p>We don't store your questions with your name.</p><Button variant="danger">Delete my data</Button></div>
  </main></div>;
}

function StaffLayout({ go, active, children, toast }: { go: (s: Screen) => void; active: string; children: ReactNode; toast?: ReactNode }) {
  const nav = [["📢", "Aushänge", "dashboard"], ["📄", "Dokumente", "documents"], ["👨‍👩‍👧", "Eltern", "parents"], ["⚙", "Einstellungen", "dashboard"]];
  return <div className="staff-shell">
    <header className="staff-top"><Logo onClick={() => go("welcome")} /><span>Kita Sonnenblume <i /> Team-Bereich</span><div className="user"><span>FW</span><b>Frau Weber</b><span>⌄</span></div></header>
    <aside className="sidebar"><nav>{nav.map(([icon, name, screen]) => <button className={active === name ? "active" : ""} onClick={() => go(screen as Screen)} key={name}><span>{icon}</span>{name}</button>)}</nav><div className="sidebar-help"><b>Hilfe benötigt?</b><p>Wir sind für Sie da.</p><button>Hilfe öffnen →</button></div></aside>
    <main className="staff-main">{toast}{children}</main>
  </div>;
}

function KitaLogin({ go }: { go: (s: Screen) => void }) {
  return <main className="login-page"><Logo onClick={() => go("welcome")} /><div className="login-card"><div className="login-mark">⌂</div><span className="eyebrow">Kita Companion</span><h1>Für Kita-Teams</h1><p>Teilen Sie Informationen einmal.<br />Alle Eltern verstehen sie.</p><label><b>Kita-Code</b><input defaultValue="SONNE" /></label><Button className="full" onClick={() => go("dashboard")}>Anmelden <span>→</span></Button><small>Demo-Zugang · Keine echten Daten</small></div></main>;
}

const announcements = [
  ["⚠️", "Ausflug: Einverständniserklärung unterschreiben", "Frist Mi, 4. Nov"],
  ["🏮", "Laternenfest", "Do, 5. Nov, 17:00"],
  ["📅", "Kita geschlossen (Teamfortbildung)", "Fr, 6. Nov"],
  ["🧥", "Matschhose und Gummistiefel mitbringen", "Täglich"],
];

function AnnouncementList({ published = false }: { published?: boolean }) {
  const list = published ? [["🏮", "Laternenfest", "Do, 5. Nov, 17:00"], ...announcements] : announcements;
  return <section className="announcement-section"><div className="list-title"><h2>Aktuelle Aushänge</h2><span>{list.length} aktiv</span></div><div className="announcement-list">{list.map((x, i) => <article key={`${x[1]}${i}`} className={published && i === 0 ? "new-item" : ""}><span className="list-icon">{x[0]}</span><div><div className="status-line"><h3>{x[1]}</h3>{published && i === 0 && <Tag>Neu</Tag>}<Tag kind="success">✓ Veröffentlicht</Tag></div><p>{x[2]} · <span>gesehen von 11 von 14 Familien</span></p></div><IconButton label="Bearbeiten">✎</IconButton><IconButton label="Löschen">⌫</IconButton></article>)}</div></section>;
}

function AnnouncementForm({ go }: { go: (s: Screen) => void }) {
  return <section className="form-card"><div className="form-title"><div className="round-icon">＋</div><div><h2>Neuer Aushang</h2><p>In weniger als einer Minute veröffentlicht.</p></div></div>
    <div className="form-grid"><label className="wide"><b>Titel</b><input defaultValue="Laternenfest" /></label><label><b>Datum und Uhrzeit</b><input defaultValue="Do, 5. Nov, 17:00" /></label><label className="wide"><b>Nachricht an die Eltern <small>(auf Deutsch, in einfachen Worten)</small></b><textarea defaultValue="Am Donnerstag feiern wir unser Laternenfest. Bitte bastelt mit eurem Kind eine Laterne und bringt sie um 17 Uhr mit. Eltern sind herzlich eingeladen!" /></label><label><b>Bitte mitbringen <small>(optional)</small></b><input defaultValue="Laterne" /></label><label className="check-label"><input type="checkbox" /> <b>Mit Frist</b><input type="date" /></label></div>
    <fieldset className="type-select"><legend>Art des Aushangs</legend>{["Veranstaltung", "Kita geschlossen", "Frist", "Erinnerung"].map((x, i) => <button className={i === 0 ? "selected" : ""} key={x}>{["☆", "⊘", "!", "↻"][i]} {x}</button>)}</fieldset>
    <div className="globe-info">◎ <span><b>Automatisch in 5 Sprachen</b><br />Eltern sehen diesen Aushang auf Arabisch, Ukrainisch, Türkisch, Englisch oder Spanisch.</span></div>
    <div className="form-actions"><Button variant="secondary" onClick={() => go("preview")}>⊙ Vorschau für Eltern</Button><Button onClick={() => go("published")}>Veröffentlichen →</Button></div>
  </section>;
}

function Dashboard({ go, published = false }: { go: (s: Screen) => void; published?: boolean }) {
  return <StaffLayout go={go} active="Aushänge" toast={published ? <><Toast>Veröffentlicht! 14 Familien sehen den Aushang jetzt in 5 Sprachen.</Toast><button className="cross-link" onClick={() => go("arabic")}>Arabische Elternansicht öffnen →</button></> : undefined}>
    <div className="page-title"><div><span className="eyebrow">Montag, 2. November 2026</span><h1>Guten Morgen, Frau Weber</h1><p>Was möchten Sie heute mit den Eltern teilen?</p></div><span className="mini-stat">● <b>14 Familien</b> verbunden</span></div>
    <AnnouncementForm go={go} /><AnnouncementList published={published} />
  </StaffLayout>;
}

function Preview({ go }: { go: (s: Screen) => void }) {
  const [arabic, setArabic] = useState(false);
  return <div className="modal-layer"><div className="preview-modal" dir={arabic ? "rtl" : "ltr"}><div className="panel-head"><div><span className="eyebrow">Vorschau</span><h1>So sehen es die Eltern</h1></div><IconButton label="Schließen" onClick={() => go("dashboard")}>×</IconButton></div>
    <div className="tabs">{["Englisch", "Arabisch", "Ukrainisch", "Türkisch"].map(x => <button className={(arabic && x === "Arabisch") || (!arabic && x === "Englisch") ? "active" : ""} onClick={() => setArabic(x === "Arabisch")} key={x}>{x}</button>)}</div>
    <div className="preview-canvas"><span className="preview-lang">◎ {arabic ? "العربية" : "English"}</span><EventCard icon="🏮" date={arabic ? "الخميس 5 نوفمبر، 17:00" : "Thu 5 Nov, 17:00"} title={arabic ? "مسيرة الفوانيس (Laternenfest)" : "Lantern walk (Laternenfest)"} bring={arabic ? "أحضر: فانوسًا منزلي الصنع" : "Bring: a homemade lantern"} note={arabic ? "تقليد خريفي ألماني: يمشي الأطفال بالفوانيس ويغنون. عادةً يشارك الوالدان." : "A German autumn tradition: children walk through the streets with lanterns and sing songs. Parents usually come along."} tag={<Tag>{arabic ? "جديد" : "New"}</Tag>} rtl={arabic} /></div>
    <p className="auto-note">✦ Die kulturellen Erklärungen werden automatisch ergänzt.</p>
    <div className="form-actions"><Button variant="secondary" onClick={() => go("dashboard")}>← Zurück bearbeiten</Button><Button onClick={() => go("published")}>Veröffentlichen →</Button></div>
  </div></div>;
}

function Documents({ go }: { go: (s: Screen) => void }) {
  const docs = [["📘", "Elternhandbuch", "aktualisiert 15. Okt · 6 Seiten"], ["📋", "Hausordnung", "aktualisiert 10. Okt"], ["🗓️", "Jahreskalender 2026/27", "aktualisiert 1. Okt"], ["✉️", "Elternbriefe", "3 Briefe"]];
  return <StaffLayout go={go} active="Dokumente"><div className="page-title"><div><span className="eyebrow">Wissensbasis</span><h1>Dokumente der Kita</h1><p>Aus diesen Dokumenten beantwortet die App die Fragen der Eltern. Halten Sie sie aktuell.</p></div><Button>＋ Dokument hinzufügen</Button></div><div className="document-grid">{docs.map((d, i) => <article className="document-card" key={d[1]}><span>{d[0]}</span><div><h2>{d[1]}</h2><p>{d[2]}</p></div><Button variant="secondary" onClick={() => i === 1 && go("editor")}>Bearbeiten</Button></article>)}</div><div className="safe-card">✓ <div><b>Die Antworten bleiben verlässlich</b><p>Die App nutzt nur die Dokumente Ihrer Kita. Sie erfindet keine Informationen.</p></div></div></StaffLayout>;
}

function Editor({ go }: { go: (s: Screen) => void }) {
  const [saved, setSaved] = useState(false);
  return <StaffLayout go={go} active="Dokumente" toast={saved ? <Toast>Gespeichert. Die App nutzt ab jetzt die neue Version.</Toast> : undefined}><button className="breadcrumb" onClick={() => go("documents")}>Dokumente <span>›</span> Hausordnung</button><div className="editor-head"><div><span className="doc-large">📋</span><div><h1>Hausordnung</h1><p>Zuletzt aktualisiert am 10. Oktober 2026</p></div></div><Tag kind="success">● Aktiv</Tag></div><section className="editor-card"><label><b>Inhalt des Dokuments</b><textarea defaultValue={"§1 Öffnungszeiten\nMontag bis Freitag, 7:30 bis 16:30 Uhr.\n\n§2 Bringen und Abholen\nBitte bringen Sie Ihr Kind bis 9:00 Uhr.\n\n§3 Abholung durch andere Personen\nNur mit schriftlicher Vollmacht.\n\n§4 Krankheit\nKinder müssen 24 Stunden fieberfrei sein, bevor sie die Kita wieder besuchen. Bitte melden Sie Ihr Kind bis 8:30 Uhr krank.\n\n§5 Kleidung\nBitte geben Sie täglich Matschhose, Gummistiefel und Wechselkleidung mit."} /></label><p className="editor-hint">✦ Änderungen stehen den Eltern direkt nach dem Speichern zur Verfügung.</p><div className="form-actions"><Button variant="secondary" onClick={() => go("documents")}>Abbrechen</Button><Button onClick={() => setSaved(true)}>Speichern</Button></div></section></StaffLayout>;
}

function Parents({ go }: { go: (s: Screen) => void }) {
  return <StaffLayout go={go} active="Eltern"><div className="page-title"><div><span className="eyebrow">Anonym & geschützt</span><h1>Eltern-Übersicht</h1><p>Sehen Sie, welche Informationen Familien gerade brauchen.</p></div></div><div className="stat-grid"><article><span>👨‍👩‍👧</span><b>14</b><p>Familien verbunden</p></article><article><span>◎</span><b>5</b><p>Sprachen</p></article><article><span>?</span><b>38</b><p>Fragen diese Woche</p></article></div>
    <div className="analytics-grid"><section className="analytics-card"><h2>Sprachen der Familien</h2>{[["Arabisch", 5], ["Ukrainisch", 4], ["Türkisch", 3], ["Englisch", 1], ["Spanisch", 1]].map(([x, n], i) => <div className="bar-row" key={x}><span>{x}</span><div><i style={{ width: `${Number(n) * 18}%` }} /></div><b>{n}</b></div>)}</section>
    <section className="analytics-card"><h2>Häufige Fragen diese Woche</h2>{[["Was ist die Eingewöhnung?", "6×"], ["Was muss mein Kind zum Laternenfest mitbringen?", "4×"], ["Darf mein Kind mit Schnupfen kommen?", "3×"]].map((x, i) => <div className="question-row" key={x[0]}><span>{i + 1}</span><p>{x[0]}</p><b>{x[1]}</b></div>)}<div className="tip">💡 <span><b>Tipp</b><br />Ergänzen Sie diese Infos im Elternhandbuch.</span></div></section></div>
    <section className="unanswered"><div><h2>Fragen ohne Antwort in den Dokumenten</h2><p>Diese Fragen wurden anonym zusammengefasst.</p></div><article><span>1</span><p>„Darf mein Kind eigenes Mittagessen mitbringen?“</p><Button variant="secondary" onClick={() => go("editor")}>Zum Dokument →</Button></article><article><span>2</span><p>„Gibt es einen Fotografen-Termin?“</p><Button variant="secondary" onClick={() => go("editor")}>Zum Dokument →</Button></article></section><p className="anonymous-note">⌾ Keine Namen, keine persönlichen Daten.</p>
  </StaffLayout>;
}

function DesignSystem({ go }: { go: (s: Screen) => void }) {
  return <main className="system-page"><div className="system-head"><Logo onClick={() => go("welcome")} /><Button variant="secondary" onClick={() => go("welcome")}>← Back to prototype</Button></div><span className="eyebrow">Shared foundation</span><h1>Kita Companion design system</h1><p>Warm, calm, trustworthy and inclusive. Built for quick understanding in LTR and RTL.</p>
    <section><h2>Colour & type</h2><div className="swatches">{[["Warm canvas", "#FBF8F3"], ["Sunflower", "#F2B705"], ["Deep teal", "#2F8F83"], ["Ink", "#1F2A2E"], ["Lavender", "#F1EDFB"], ["Success", "#2E9E5B"]].map(x => <div key={x[0]}><i style={{ background: x[1] }} /><b>{x[0]}</b><small>{x[1]}</small></div>)}</div></section>
    <section><h2>Actions & status</h2><div className="component-row"><Button>Primary action</Button><Button variant="secondary">Secondary</Button><Button variant="tertiary">Tertiary link</Button><Tag kind="deadline">⚠ Deadline</Tag><Tag kind="closed">⊘ Closed</Tag><Tag>New</Tag><Tag kind="success">✓ Published</Tag></div></section>
    <section><h2>Core components</h2><div className="system-grid"><EventCard icon="🏮" date="Thu 5 Nov, 17:00" title="Lantern walk (Laternenfest)" bring="Bring: a homemade lantern" note="A German autumn tradition. Parents usually come along." tag={<Tag>New</Tag>} /><AnswerCard /></div></section>
    <section><h2>Parent states</h2><div className="state-grid"><div className="skeleton-card"><p>Reading your Kita's documents…</p><i /><i /><i /></div><div className="state-card"><b>🌻 No news this week</b><p>New information will appear here.</p></div><div className="state-card error"><b>! Something went wrong</b><p>Please try again in a moment.</p></div><div className="state-card"><b>⌂ Kita code not found</b><p>We can't find this Kita code. Please check with your Kita.</p></div></div></section>
    <section><h2>Kita staff states</h2><div className="state-grid"><div className="state-card"><b>📢 Noch keine Aushänge</b><p>Schreiben Sie den ersten!</p></div><div className="state-card error"><b>! Etwas ist schiefgelaufen</b><p>Bitte versuchen Sie es gleich noch einmal.</p></div><div className="state-card"><b>⌂ Kita-Code nicht gefunden</b><p>Bitte prüfen Sie den Code und versuchen Sie es erneut.</p></div><div className="state-card"><b>✓ Gespeichert</b><p>Die App nutzt ab jetzt die neue Version.</p></div></div></section>
  </main>;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("welcome");
  const go = (next: Screen) => { setScreen(next); window.scrollTo({ top: 0, behavior: "smooth" }); };
  switch (screen) {
    case "welcome": return <Welcome go={go} />;
    case "onboarding": return <Onboarding go={go} />;
    case "home": return <Home go={go} />;
    case "ask": return <AskScreen go={go} />;
    case "not-found": return <NotFound go={go} />;
    case "composer": return <Composer go={go} />;
    case "result": return <Result go={go} />;
    case "arabic": return <Home go={go} arabic published />;
    case "settings": return <Settings go={go} />;
    case "kita-login": return <KitaLogin go={go} />;
    case "dashboard": return <Dashboard go={go} />;
    case "preview": return <Preview go={go} />;
    case "published": return <Dashboard go={go} published />;
    case "documents": return <Documents go={go} />;
    case "editor": return <Editor go={go} />;
    case "parents": return <Parents go={go} />;
    case "system": return <DesignSystem go={go} />;
  }
}
